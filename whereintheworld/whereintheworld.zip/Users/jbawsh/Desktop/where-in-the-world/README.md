Assignment 3

Node.js w/ express using mongo on Heroku.

1. I believe all aspects of the project have been implemented correctly.

2. I got help from Larry and Julia.

3. I spent roughly 7 hours on this assignment.